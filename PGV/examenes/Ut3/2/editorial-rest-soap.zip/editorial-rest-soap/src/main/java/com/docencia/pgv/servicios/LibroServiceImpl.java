package com.docencia.pgv.servicios;

import java.util.List;
import org.springframework.stereotype.Service;
import com.docencia.pgv.interfaces.LibroService;
import com.docencia.pgv.modelo.Libro;


public class LibroServiceImpl implements LibroService {
    @Override public List<Libro> findAll() { return List.of(); }
    @Override public Libro findByIdOrThrow(Long id) { throw new UnsupportedOperationException("TODO"); }
    @Override public List<Libro> findByAutorOrThrow(Long idAutor) { throw new UnsupportedOperationException("TODO"); }
    @Override public Libro create(Libro libro) { throw new UnsupportedOperationException("TODO"); }
    @Override public void delete(Long id) { throw new UnsupportedOperationException("TODO"); }
}
