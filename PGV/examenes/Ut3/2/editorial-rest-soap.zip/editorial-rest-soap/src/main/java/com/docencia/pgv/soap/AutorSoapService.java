package com.docencia.pgv.soap;

import java.util.List;
import com.docencia.pgv.modelo.Autor;
import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.jws.WebService;

public interface AutorSoapService {
    List<Autor> getAllAuthors();
    Autor getAuthorById(@WebParam(name = "id") Long id);
    Autor createAuthor(@WebParam(name = "nombre") String nombre, @WebParam(name = "pais") String pais);
    void deleteAuthor(@WebParam(name = "id") Long id);
}
