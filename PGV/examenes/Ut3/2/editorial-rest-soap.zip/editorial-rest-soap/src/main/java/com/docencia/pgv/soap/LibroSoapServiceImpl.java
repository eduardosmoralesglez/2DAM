package com.docencia.pgv.soap;

import java.util.List;
import org.springframework.stereotype.Service;
import com.docencia.pgv.modelo.Libro;
import jakarta.jws.WebService;

public class LibroSoapServiceImpl implements LibroSoapService {
    @Override public List<Libro> getAllBooks() { return List.of(); }
    @Override public Libro getBookById(Long id) { throw new UnsupportedOperationException("TODO"); }
    @Override public List<Libro> getBooksByAuthor(Long idAutor) { throw new UnsupportedOperationException("TODO"); }
    @Override public Libro createBook(String titulo, Integer anioPublicacion, Long idAutor) { throw new UnsupportedOperationException("TODO"); }
    @Override public void deleteBook(Long id) { throw new UnsupportedOperationException("TODO"); }
}
