package com.docencia.pgv.rest;

import java.util.List;
import org.springframework.web.bind.annotation.*;
import com.docencia.pgv.interfaces.AutorService;
import com.docencia.pgv.modelo.Autor;


public class AutorRestController {

}
