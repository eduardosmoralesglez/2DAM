package com.docencia.pgv.rest;

import java.util.List;
import org.springframework.web.bind.annotation.*;
import com.docencia.pgv.interfaces.LibroService;
import com.docencia.pgv.modelo.Libro;


public class LibroRestController {

}
