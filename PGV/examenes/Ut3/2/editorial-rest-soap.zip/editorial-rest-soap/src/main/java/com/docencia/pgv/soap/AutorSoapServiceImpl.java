package com.docencia.pgv.soap;

import java.util.List;
import org.springframework.stereotype.Service;
import com.docencia.pgv.modelo.Autor;
import jakarta.jws.WebService;

public class AutorSoapServiceImpl implements AutorSoapService {
    @Override public List<Autor> getAllAuthors() { return List.of(); }
    @Override public Autor getAuthorById(Long id) { throw new UnsupportedOperationException("TODO"); }
    @Override public Autor createAuthor(String nombre, String pais) { throw new UnsupportedOperationException("TODO"); }
    @Override public void deleteAuthor(Long id) { throw new UnsupportedOperationException("TODO"); }
}
