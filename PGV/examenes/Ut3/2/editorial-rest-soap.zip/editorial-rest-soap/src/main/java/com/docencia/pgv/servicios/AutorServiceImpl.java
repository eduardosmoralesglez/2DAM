package com.docencia.pgv.servicios;

import java.util.List;
import org.springframework.stereotype.Service;
import com.docencia.pgv.interfaces.AutorService;
import com.docencia.pgv.modelo.Autor;


public class AutorServiceImpl implements AutorService {
    @Override public List<Autor> findAll() { return List.of(); }
    @Override public Autor findByIdOrThrow(Long id) { throw new UnsupportedOperationException("TODO"); }
    @Override public Autor create(Autor autor) { throw new UnsupportedOperationException("TODO"); }
    @Override public void delete(Long id) { throw new UnsupportedOperationException("TODO"); }
}
