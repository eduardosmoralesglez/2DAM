package com.docencia.pgv.soap;

import java.util.List;
import com.docencia.pgv.modelo.Libro;
import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.jws.WebService;

public interface LibroSoapService {
    List<Libro> getAllBooks();
    Libro getBookById(@WebParam(name = "id") Long id);
    List<Libro> getBooksByAuthor(@WebParam(name = "idAutor") Long idAutor);
    Libro createBook(@WebParam(name = "titulo") String titulo,
                     @WebParam(name = "anioPublicacion") Integer anioPublicacion,
                     @WebParam(name = "idAutor") Long idAutor);
    void deleteBook(@WebParam(name = "id") Long id);
}
