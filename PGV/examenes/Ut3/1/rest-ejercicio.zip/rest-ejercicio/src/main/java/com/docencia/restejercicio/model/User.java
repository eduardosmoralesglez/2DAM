package com.docencia.restejercicio.model;

public class User {

    private Long id;
    private String username;
    private String email;

    public User() {
    }

    public User(Long id, String username, String email) {
        this.id = id;
        this.username = username;
        this.email = email;
    }

    public Long getId() {
        return null;
    }

    public void setId(Long id) {
        this.id = null;
    }

    public String getUsername() {
        return null;
    }

    public void setUsername(String username) {
        this.username = null;
    }

    public String getEmail() {
        return null;
    }

    public void setEmail(String email) {
        this.email = null;
    }
}
