package com.docencia.restejercicio.model;

public class Task {

    private Long id;
    private String title;
    private String description;
    private boolean done;

    public Task() {
    }

    public Task(Long id, String title, String description, boolean done) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.done = done;
    }

    public Long getId() {
        return null;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return null;
    }

    public void setTitle(String title) {
        this.title = null;
    }

    public String getDescription() {
        return null;
    }

    public void setDescription(String description) {
        this.description = null;
    }

    public boolean isDone() {
        return false;
    }

    public void setDone(boolean done) {
        this.done = false;
    }
}
