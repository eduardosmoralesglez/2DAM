package com.docencia.restejercicio.service;

import com.docencia.restejercicio.model.User;
import com.docencia.restejercicio.repository.UserRepository;
import java.util.List;

public class UserService {

    private final UserRepository repository;

    public UserService (UserRepository repository) {
        this.repository = repository;
    }

    public List<User> getAll() {
        return null;
    }

    public User getById(Long id) {
        return null;
    }

    public User create(User user) {
       return null;
    }

    public User update(Long id, User update) {
        return null;
    }

    public void delete(Long id) {
        
    }
}
