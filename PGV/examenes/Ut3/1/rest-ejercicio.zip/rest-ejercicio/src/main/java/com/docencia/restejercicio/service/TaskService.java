package com.docencia.restejercicio.service;

import com.docencia.restejercicio.model.Task;
import com.docencia.restejercicio.repository.TaskRepository;


import java.util.List;

public class TaskService {

    private  final TaskRepository repository;

    public TaskService(TaskRepository repository) {
        this.repository = repository;
    }

    public List<Task> getAll() {
        return null;
    }

    public Task getById(Long id) {
        return null;
    }

    public Task create(Task task) {
        return null;
    }

    public Task update(Long id, Task update) {
        return null;
    }

    public void delete(Long id) {
        
    }
}
