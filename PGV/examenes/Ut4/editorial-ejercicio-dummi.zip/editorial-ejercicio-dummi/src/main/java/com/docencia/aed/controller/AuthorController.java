package com.docencia.aed.controller;

import com.docencia.aed.entity.Author;
import com.docencia.aed.entity.Book;
import com.docencia.aed.service.IAuthorService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


public class AuthorController {

    @GetMapping("/authors")
    public List<Author> getAllAuthors() {
        throw new UnsupportedOperationException("No implementado");
    }

    @GetMapping("/authors/{id}")
    public Author getAuthorById(@PathVariable Long id) {
        throw new UnsupportedOperationException("No implementado");
    }

    @PostMapping("/authors")
    public ResponseEntity<Author> createAuthor(@Valid @RequestBody Author author) {
        throw new UnsupportedOperationException("No implementado");
    }

    @GetMapping("/authors/{id}/books")
    public List<Book> getBooksByAuthor(@PathVariable("id") Long authorId) {
        throw new UnsupportedOperationException("No implementado");
    }
}
