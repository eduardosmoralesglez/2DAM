package com.docencia.aed.controller;

import com.docencia.aed.entity.Book;
import com.docencia.aed.service.IBookService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;



public class BookController {

    @GetMapping("/books")
    public List<Book> getAllBooks(@RequestParam(value = "authorId", required = false) Long authorId) {
throw new UnsupportedOperationException("No implementado");    }

    @Operation(summary = "Get book by ID")
    @GetMapping("/books/{id}")
    public Book getBookById(@PathVariable Long id) {
        throw new UnsupportedOperationException("No implementado");
    }

    @Operation(summary = "Create a book for an author")
    @PostMapping("/books")
    public ResponseEntity<Book> createBook(@RequestParam("authorId") Long authorId,
                                           @Valid @RequestBody Book book) {
        throw new UnsupportedOperationException("No implementado");
    }
}
