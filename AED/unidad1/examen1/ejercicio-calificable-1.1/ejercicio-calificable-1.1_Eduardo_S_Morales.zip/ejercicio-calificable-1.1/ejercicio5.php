<?php
/**
 * Funcion para contar las letras y vocales 
 * @param string $cadena
 * @return void
 */
function ContadorLetras(string $cadena) : array {
    
}

?>