<?php
    $path = "marco.txt";
    $file = fopen($path, "r");
    

?>