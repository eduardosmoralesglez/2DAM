package com.biblioteca.service.impl;

import com.biblioteca.model.Socio;
import com.biblioteca.service.SocioService;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class SocioServiceImpl implements SocioService {

    @Override
    public Socio crearSocio(String nombre, String email, LocalDate fechaAlta) {
        throw new UnsupportedOperationException("TODO");
    }

    @Override
    public Socio obtenerSocioPorId(Long id) {
        throw new UnsupportedOperationException("TODO");
    }

    @Override
    public List<Socio> listarSocios() {
        throw new UnsupportedOperationException("TODO");
    }

    @Override
    public void eliminarSocio(Long id) {
        throw new UnsupportedOperationException("TODO");
    }
}
