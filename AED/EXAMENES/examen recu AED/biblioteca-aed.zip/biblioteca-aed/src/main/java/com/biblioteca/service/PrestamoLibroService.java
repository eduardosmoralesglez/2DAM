package com.biblioteca.service;

import com.biblioteca.model.PrestamoLibro;

import java.time.LocalDate;
import java.util.List;

public interface PrestamoLibroService {
    PrestamoLibro prestarLibro(Long socioId, Long libroId, LocalDate fechaInicio);
    PrestamoLibro devolverLibro(Long prestamoId);
    List<PrestamoLibro> listarPrestamosActivosPorSocio(Long socioId);
    List<PrestamoLibro> listarPrestamosActivosPorLibro(Long libroId);
}
