package com.biblioteca.model;

import jakarta.persistence.*;
import java.time.LocalDate;


//LA TABLA SE DEBE DE LLAMAR PRESTAMO_LIBRO
public class PrestamoLibro {

    private Long id;

    private Socio socio;
    private Libro libro;

    private LocalDate fechaInicio;
    private LocalDate fechaFin;

    @Enumerated(EnumType.STRING)
    private PrestamoEstado estado;

    public PrestamoLibro() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Socio getSocio() { return socio; }
    public void setSocio(Socio socio) { this.socio = socio; }

    public Libro getLibro() { return libro; }
    public void setLibro(Libro libro) { this.libro = libro; }

    public LocalDate getFechaInicio() { return fechaInicio; }
    public void setFechaInicio(LocalDate fechaInicio) { this.fechaInicio = fechaInicio; }

    public LocalDate getFechaFin() { return fechaFin; }
    public void setFechaFin(LocalDate fechaFin) { this.fechaFin = fechaFin; }

    public PrestamoEstado getEstado() { return estado; }
    public void setEstado(PrestamoEstado estado) { this.estado = estado; }
}
