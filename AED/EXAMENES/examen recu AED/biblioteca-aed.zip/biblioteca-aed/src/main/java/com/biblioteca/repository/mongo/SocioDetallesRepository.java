package com.biblioteca.repository.mongo;


public interface SocioDetallesRepository{
}
