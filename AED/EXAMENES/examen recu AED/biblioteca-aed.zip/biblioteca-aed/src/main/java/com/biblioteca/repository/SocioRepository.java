package com.biblioteca.repository;


public interface SocioRepository {

}
