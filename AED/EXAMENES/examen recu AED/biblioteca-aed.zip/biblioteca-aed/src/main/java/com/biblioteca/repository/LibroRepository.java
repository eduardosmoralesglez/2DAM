package com.biblioteca.repository;

public interface LibroRepository {}
