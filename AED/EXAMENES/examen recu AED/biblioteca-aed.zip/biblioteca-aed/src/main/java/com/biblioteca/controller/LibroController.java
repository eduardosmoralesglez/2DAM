package com.biblioteca.controller;

import com.biblioteca.dto.LibroCreateRequest;
import com.biblioteca.model.Libro;
import com.biblioteca.service.LibroService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/libros")
public class LibroController {

    private final LibroService libroService;

    public LibroController(LibroService libroService) {
        this.libroService = libroService;
    }

    @PostMapping
    public Libro crear(@RequestBody LibroCreateRequest req) {
        return libroService.crearLibro(req.isbn, req.titulo, req.autor, req.anio);
    }

    @GetMapping
    public List<Libro> listar() {
        return libroService.listar();
    }

    @GetMapping("/isbn/{isbn}")
    public Libro obtenerPorIsbn(@PathVariable String isbn) {
        return libroService.obtenerLibroPorIsbn(isbn);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) {
        libroService.eliminarLibro(id);
    }
}
