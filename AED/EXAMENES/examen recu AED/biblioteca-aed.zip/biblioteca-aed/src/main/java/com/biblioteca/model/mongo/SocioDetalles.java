package com.biblioteca.model.mongo;


//LA TABLA O LO QUE CREES SE DEBE DE LLAMAR SOCIO_DETALLES
public class SocioDetalles {

    private String id;
    private Long socioId;
    private String telefono;
    private String direccion;
    private String notas;

    public SocioDetalles() {}

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public Long getSocioId() { return socioId; }
    public void setSocioId(Long socioId) { this.socioId = socioId; }

    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = telefono; }

    public String getDireccion() { return direccion; }
    public void setDireccion(String direccion) { this.direccion = direccion; }

    public String getNotas() { return notas; }
    public void setNotas(String notas) { this.notas = notas; }
}
