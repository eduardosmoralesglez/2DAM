package com.biblioteca.model;

import jakarta.persistence.*;
import java.time.LocalDate;

//LA TABLA SE DEBE DE LLAMAR SOCIO
public class Socio {

    private Long id;

    private String nombre;

    private String email;

    private LocalDate fechaAlta;

    public Socio() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public LocalDate getFechaAlta() { return fechaAlta; }
    public void setFechaAlta(LocalDate fechaAlta) { this.fechaAlta = fechaAlta; }
}
