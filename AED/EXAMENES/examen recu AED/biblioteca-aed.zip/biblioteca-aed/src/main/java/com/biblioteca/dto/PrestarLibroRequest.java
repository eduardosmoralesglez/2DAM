package com.biblioteca.dto;

import java.time.LocalDate;

public class PrestarLibroRequest {
    public Long socioId;
    public Long libroId;
    public LocalDate fechaInicio;
}
