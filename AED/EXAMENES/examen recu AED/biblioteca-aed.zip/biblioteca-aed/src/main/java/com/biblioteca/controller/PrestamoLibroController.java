package com.biblioteca.controller;

import com.biblioteca.dto.PrestarLibroRequest;
import com.biblioteca.model.PrestamoLibro;
import com.biblioteca.service.PrestamoLibroService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/prestamos-libros")
public class PrestamoLibroController {

    private final PrestamoLibroService prestamoLibroService;

    public PrestamoLibroController(PrestamoLibroService prestamoLibroService) {
        this.prestamoLibroService = prestamoLibroService;
    }

    @PostMapping
    public PrestamoLibro prestar(@RequestBody PrestarLibroRequest req) {
        return prestamoLibroService.prestarLibro(req.socioId, req.libroId, req.fechaInicio);
    }

    @PostMapping("/{id}/devolver")
    public PrestamoLibro devolver(@PathVariable Long id) {
        return prestamoLibroService.devolverLibro(id);
    }

    @GetMapping("/activos/socio/{socioId}")
    public List<PrestamoLibro> activosPorSocio(@PathVariable Long socioId) {
        return prestamoLibroService.listarPrestamosActivosPorSocio(socioId);
    }

    @GetMapping("/activos/libro/{libroId}")
    public List<PrestamoLibro> activosPorLibro(@PathVariable Long libroId) {
        return prestamoLibroService.listarPrestamosActivosPorLibro(libroId);
    }
}
