package com.biblioteca.repository;



public interface PrestamoLibroRepository {

}