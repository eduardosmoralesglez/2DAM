package com.biblioteca.service.impl;

import com.biblioteca.model.Libro;
import com.biblioteca.service.LibroService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LibroServiceImpl implements LibroService {

    @Override
    public Libro crearLibro(String isbn, String titulo, String autor, int anio) {
        throw new UnsupportedOperationException("TODO");
    }

    @Override
    public List<Libro> listar() {
        throw new UnsupportedOperationException("TODO");
    }

    @Override
    public Libro obtenerLibroPorIsbn(String isbn) {
        throw new UnsupportedOperationException("TODO");
    }

    @Override
    public void eliminarLibro(Long id) {
        throw new UnsupportedOperationException("TODO");
    }
}
