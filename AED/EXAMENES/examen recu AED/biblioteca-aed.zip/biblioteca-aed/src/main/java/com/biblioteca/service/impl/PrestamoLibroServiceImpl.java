package com.biblioteca.service.impl;

import com.biblioteca.model.PrestamoLibro;
import com.biblioteca.service.PrestamoLibroService;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class PrestamoLibroServiceImpl implements PrestamoLibroService {

    @Override
    public PrestamoLibro prestarLibro(Long socioId, Long libroId, LocalDate fechaInicio) {
        throw new UnsupportedOperationException("TODO");
    }

    @Override
    public PrestamoLibro devolverLibro(Long prestamoId) {
        throw new UnsupportedOperationException("TODO");
    }

    @Override
    public List<PrestamoLibro> listarPrestamosActivosPorSocio(Long socioId) {
        throw new UnsupportedOperationException("TODO");
    }

    @Override
    public List<PrestamoLibro> listarPrestamosActivosPorLibro(Long libroId) {
        throw new UnsupportedOperationException("TODO");
    }
}
