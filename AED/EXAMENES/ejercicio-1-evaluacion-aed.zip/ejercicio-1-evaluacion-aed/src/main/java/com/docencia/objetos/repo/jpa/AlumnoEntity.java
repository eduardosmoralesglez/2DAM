package com.docencia.objetos.repo.jpa;

import java.util.Objects;
import jakarta.persistence.*;

@Entity
@Table(name="alumnos")
public class AlumnoEntity {
  
  @Id
  @GeneratedValue(strategy=GenerationType.IDENTITY)
  private Long id;

  private String nombre;
  
  @Column(unique = true)
  private String email;
  
  private String ciclo;

  private RolEntity rol;

  public AlumnoEntity() {
  }

  public AlumnoEntity(Long id, String nombre, String email, String ciclo) {

  }

  public AlumnoEntity(Long id, String nombre, String email, String ciclo, RolEntity rol) {

  }

  public Long getId() {
    return null;
  }

  public void setId(Long id) {
    
  }

  public String getNombre() {
    return null;
  }

  public void setNombre(String nombre) {
   
  }

  public String getEmail() {
    return null;
  }

  public void setEmail(String email) {
    
  }

  public String getCiclo() {
    return null;
  }

  public void setCiclo(String ciclo) {
    
  }

  public RolEntity getRol() {
    return null;
  }

  public void setRol(RolEntity rol) {
    
  }


}
