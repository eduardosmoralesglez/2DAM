package com.docencia.objetos.repo.jpa;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "roles")
public class RolEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(nullable = false, unique = true)
  private String nombre;

  private List<AlumnoEntity> alumnos = new ArrayList<>();

  public RolEntity() {
  }

  public RolEntity(Long id, String nombre) {

  }

  public Long getId() {
   return null;
  }

  public void setId(Long id) {
    
  }

  public String getNombre() {
   return null;
  }

  public void setNombre(String nombre) {
    
  }

  public List<AlumnoEntity> getAlumnos() {
    return null;
  }

  public void setAlumnos(List<AlumnoEntity> alumnos) {

  }

}
