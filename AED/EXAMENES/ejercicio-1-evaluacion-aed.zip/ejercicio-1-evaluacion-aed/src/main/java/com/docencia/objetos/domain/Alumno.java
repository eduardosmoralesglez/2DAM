package com.docencia.objetos.domain;


public class Alumno {
  private Long id;
  private String nombre;
  private String email;
  private String ciclo;
  private Rol rol;   

 
  public Alumno() {
  }


  public Alumno(Long id) {

  }

  public Alumno(Long id, String nombre, String email, String ciclo) {
    
  }

  
  public Alumno(Long id, String nombre, String email, String ciclo, Rol rol) {
  
  }

  public Long getId() {
    return null;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getNombre() {
    return null;
  }

  public void setNombre(String nombre) {

  }

  public String getEmail() {
    return null;
  }

  public void setEmail(String email) {

  }

  public String getCiclo() {
    return null;
  }

  public void setCiclo(String ciclo) {

  }

  public Rol getRol() {
    return null;
  }

  public void setRol(Rol rol) {
    this.rol = rol;
  }

  public Alumno id(Long id) {
    return null;
  }

  public Alumno nombre(String nombre) {
    return null;
  }

  public Alumno email(String email) {
    return null;
  }

  public Alumno ciclo(String ciclo) {
    return null;
  }

  public Alumno rol(Rol rol) {
    return null;
  }
}