package com.docencia.objetos.domain;

public class Rol {

  private Long id;
  private String nombre;

  public Rol() {
  }

  public Rol(Long id) {

  }

  public Rol(Long id, String nombre) {

  }

  public Long getId() {
    return null;
  }

  public void setId(Long id) {

  }

  public String getNombre() {
    return null;
  }

  public void setNombre(String nombre) {
  }

  
}
